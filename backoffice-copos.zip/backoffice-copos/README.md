# Cristalia Export – Back-office

Sistema web para uma exportadora de copos de vidro: os preços são calculados em USD com **100% de lucro sobre o custo** e convertidos para a moeda do país solicitante.

## Como executar
Requer Node.js 18+.

    npm install
    npm start        # http://localhost:3000

## Arquitetura
- **Front-end** (`public/`): HTML, CSS e JavaScript puro; consome a API via `fetch`.
- **Back-end** (Node.js + Express): API REST em JSON.
- **Banco**: SQLite (`data/backoffice.db`), criado e populado automaticamente.
- **POO**: `Produto` e `Moeda` (modelos com validação), `Repositorio` → `ProdutoRepositorio`/`MoedaRepositorio` (herança), `PrecoService` (regra de negócio), `Banco` (conexão/esquema).

## API
| Método | Rota | Função |
|---|---|---|
| GET/POST | `/api/produtos` | listar / criar |
| PUT/DELETE | `/api/produtos/:id` | atualizar / excluir |
| GET/POST | `/api/moedas` | listar / criar |
| PUT/DELETE | `/api/moedas/:id` | atualizar / excluir |
| GET | `/api/precos?pais=Brasil` ou `?moeda=BRL` | catálogo com preços na moeda local |

Taxa de câmbio = unidades da moeda por 1 USD (editável na aba Moedas).
Para alterar a margem, mude `new PrecoService(1.0)` em `src/rotas.js` (1.0 = 100%).
