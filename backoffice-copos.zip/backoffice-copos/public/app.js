const $ = (s, el = document) => el.querySelector(s);
const esc = (t) => String(t ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const moeda = (v, cod) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: cod }).format(v);

// Comunicação com a API (HTTP/JSON)
async function api(url, { method = 'GET', body } = {}) {
  const r = await fetch('/api' + url, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  const dados = r.status === 204 ? null : await r.json();
  if (!r.ok) throw new Error(dados?.erro || 'Não foi possível concluir a operação');
  return dados;
}

let timer;
function aviso(texto, erro = false) {
  const el = $('#aviso');
  el.textContent = texto;
  el.className = 'visivel' + (erro ? ' erro' : '');
  clearTimeout(timer);
  timer = setTimeout(() => (el.className = ''), 3500);
}
const seguro = (fn) => async (...a) => { try { await fn(...a); } catch (e) { aviso(e.message, true); } };

// Abas
document.querySelectorAll('.aba').forEach((b) => b.addEventListener('click', () => {
  document.querySelectorAll('.aba').forEach((x) => x.classList.toggle('ativa', x === b));
  document.querySelectorAll('.painel').forEach((p) => p.classList.toggle('ativo', p.id === b.dataset.aba));
}));

// Tabela de preços
async function carregarPrecos() {
  const pais = $('#pais').value;
  if (!pais) { $('#lista-precos').innerHTML = '<tr><td class="vazio" colspan="5">Cadastre uma moeda para ver os preços.</td></tr>'; return; }
  const { moeda: m, itens } = await api('/precos?pais=' + encodeURIComponent(pais));
  $('#th-local').textContent = `Preço em ${m.codigo}`;
  $('#cambio').textContent = `Câmbio: 1 USD = ${m.taxa} ${m.codigo}`;
  $('#lista-precos').innerHTML = itens.length ? itens.map((i) => `
    <tr><td>${esc(i.nome)}<small>${esc(i.descricao)}</small></td>
    <td class="num">${i.capacidadeMl} ml</td>
    <td class="num">${moeda(i.custoUsd, 'USD')}</td>
    <td class="num">${moeda(i.precoUsd, 'USD')}</td>
    <td class="num local">${moeda(i.preco, i.moeda)}</td></tr>`).join('')
    : '<tr><td class="vazio" colspan="5">Nenhum produto cadastrado. Adicione na aba Produtos.</td></tr>';
}

// Moedas
let moedas = [];
async function carregarMoedas() {
  moedas = await api('/moedas');
  const atual = $('#pais').value;
  $('#pais').innerHTML = moedas.map((m) => `<option value="${esc(m.pais)}">${esc(m.pais)} (${esc(m.codigo)})</option>`).join('');
  if (moedas.some((m) => m.pais === atual)) $('#pais').value = atual;
  $('#lista-moedas').innerHTML = moedas.length ? moedas.map((m) => `
    <tr><td>${esc(m.pais)}</td><td>${esc(m.codigo)}</td><td class="num">${m.taxa}</td>
    <td class="botoes"><button data-acao="editar" data-id="${m.id}">Editar</button><button class="perigo" data-acao="excluir" data-id="${m.id}">Excluir</button></td></tr>`).join('')
    : '<tr><td class="vazio" colspan="4">Nenhuma moeda cadastrada.</td></tr>';
}

// Produtos
let produtos = [];
async function carregarProdutos() {
  produtos = await api('/produtos');
  $('#lista-produtos').innerHTML = produtos.length ? produtos.map((p) => `
    <tr><td>${esc(p.nome)}<small>${esc(p.descricao)}</small></td><td class="num">${p.capacidadeMl} ml</td>
    <td class="num">${moeda(p.custoUsd, 'USD')}</td><td class="num">${p.estoque}</td>
    <td class="botoes"><button data-acao="editar" data-id="${p.id}">Editar</button><button class="perigo" data-acao="excluir" data-id="${p.id}">Excluir</button></td></tr>`).join('')
    : '<tr><td class="vazio" colspan="5">Nenhum produto cadastrado.</td></tr>';
}

// CRUD genérico dos formulários
function ligarCrud({ form, lista, rota, getLista, recarregar, nome }) {
  const f = $(form);
  const dados = () => Object.fromEntries(new FormData(f));
  f.addEventListener('submit', seguro(async (e) => {
    e.preventDefault();
    const d = dados();
    if (d.id) await api(`${rota}/${d.id}`, { method: 'PUT', body: d });
    else await api(rota, { method: 'POST', body: d });
    f.reset();
    f.elements.id.value = '';
    await recarregar();
    aviso(`${nome} salvo`);
  }));
  $('.limpar', f).addEventListener('click', () => { f.reset(); f.elements.id.value = ''; });
  $(lista).addEventListener('click', seguro(async (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    const item = getLista().find((x) => x.id === Number(b.dataset.id));
    if (b.dataset.acao === 'editar') {
      Object.keys(item).forEach((k) => { if (f.elements[k]) f.elements[k].value = item[k]; });
      f.scrollIntoView({ behavior: 'smooth', block: 'center' });
    } else if (b.dataset.acao === 'excluir' && confirm(`Excluir ${nome.toLowerCase()} "${item.nome || item.pais}"?`)) {
      await api(`${rota}/${item.id}`, { method: 'DELETE' });
      await recarregar();
      aviso(`${nome} excluído`);
    }
  }));
}

const recarregarTudo = async () => { await carregarMoedas(); await carregarProdutos(); await carregarPrecos(); };
ligarCrud({ form: '#form-produto', lista: '#lista-produtos', rota: '/produtos', getLista: () => produtos, recarregar: recarregarTudo, nome: 'Produto' });
ligarCrud({ form: '#form-moeda', lista: '#lista-moedas', rota: '/moedas', getLista: () => moedas, recarregar: recarregarTudo, nome: 'Moeda' });
$('#pais').addEventListener('change', seguro(carregarPrecos));
seguro(recarregarTudo)();
