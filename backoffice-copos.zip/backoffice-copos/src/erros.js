class ErroValidacao extends Error {}
class ErroNaoEncontrado extends Error {
  constructor(msg = 'Registro não encontrado') { super(msg); }
}
module.exports = { ErroValidacao, ErroNaoEncontrado };
