// Regra de negócio: preço de venda = custo (USD) + 100% de lucro, convertido para a moeda do país.
class PrecoService {
  constructor(margemLucro = 1.0) {
    this.margemLucro = margemLucro; // 1.0 = 100% sobre o custo
  }

  static arredondar(valor) { return Math.round(valor * 100) / 100; }

  precoVendaUsd(custoUsd) { return custoUsd * (1 + this.margemLucro); }

  converter(valorUsd, moeda) { return valorUsd * moeda.taxa; }

  calcular(produto, moeda) {
    const vendaUsd = this.precoVendaUsd(produto.custoUsd);
    return {
      produtoId: produto.id,
      nome: produto.nome,
      descricao: produto.descricao,
      capacidadeMl: produto.capacidadeMl,
      estoque: produto.estoque,
      custoUsd: PrecoService.arredondar(produto.custoUsd),
      precoUsd: PrecoService.arredondar(vendaUsd),
      preco: PrecoService.arredondar(this.converter(vendaUsd, moeda)),
      moeda: moeda.codigo,
      pais: moeda.pais,
    };
  }

  catalogo(produtos, moeda) {
    return { moeda, margemLucro: this.margemLucro, itens: produtos.map((p) => this.calcular(p, moeda)) };
  }
}
module.exports = PrecoService;
