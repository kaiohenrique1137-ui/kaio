const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');

// Taxas = unidades da moeda local por 1 USD (valores iniciais editáveis no sistema).
const MOEDAS_INICIAIS = [
  ['Estados Unidos', 'USD', 1], ['Brasil', 'BRL', 5.4], ['Alemanha', 'EUR', 0.92],
  ['França', 'EUR', 0.92], ['Reino Unido', 'GBP', 0.78], ['Japão', 'JPY', 150],
  ['Canadá', 'CAD', 1.37], ['México', 'MXN', 17.5], ['Argentina', 'ARS', 980],
];
const PRODUTOS_INICIAIS = [
  ['Copo Long Drink', 'Copo alto para drinks e refrescos', 350, 1.2, 800],
  ['Copo Old Fashioned', 'Copo baixo para destilados', 300, 1.5, 600],
  ['Taça de Vinho Tinto', 'Taça em vidro cristalino', 450, 2.1, 400],
  ['Taça de Champanhe', 'Taça flûte', 200, 1.9, 350],
  ['Caneca de Cerveja', 'Caneca de vidro grosso com alça', 500, 2.4, 500],
];

class Banco {
  constructor(arquivo = path.join(__dirname, '..', 'data', 'backoffice.db')) {
    fs.mkdirSync(path.dirname(arquivo), { recursive: true });
    this.conexao = new Database(arquivo);
    this.conexao.pragma('journal_mode = WAL');
    this.criarTabelas();
    this.semear();
  }

  criarTabelas() {
    this.conexao.exec(`
      CREATE TABLE IF NOT EXISTS moedas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        pais TEXT NOT NULL UNIQUE,
        codigo TEXT NOT NULL,
        taxa REAL NOT NULL CHECK (taxa > 0)
      );
      CREATE TABLE IF NOT EXISTS produtos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL UNIQUE,
        descricao TEXT DEFAULT '',
        capacidadeMl INTEGER NOT NULL CHECK (capacidadeMl > 0),
        custoUsd REAL NOT NULL CHECK (custoUsd >= 0),
        estoque INTEGER NOT NULL DEFAULT 0 CHECK (estoque >= 0)
      );
    `);
  }

  semear() {
    const db = this.conexao;
    if (db.prepare('SELECT COUNT(*) n FROM moedas').get().n === 0) {
      const ins = db.prepare('INSERT INTO moedas (pais, codigo, taxa) VALUES (?, ?, ?)');
      db.transaction(() => MOEDAS_INICIAIS.forEach((m) => ins.run(...m)))();
    }
    if (db.prepare('SELECT COUNT(*) n FROM produtos').get().n === 0) {
      const ins = db.prepare(
        'INSERT INTO produtos (nome, descricao, capacidadeMl, custoUsd, estoque) VALUES (?, ?, ?, ?, ?)');
      db.transaction(() => PRODUTOS_INICIAIS.forEach((p) => ins.run(...p)))();
    }
  }
}
module.exports = Banco;
