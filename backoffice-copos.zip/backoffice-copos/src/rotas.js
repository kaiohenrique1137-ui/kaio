const express = require('express');
const Produto = require('./modelos/Produto');
const Moeda = require('./modelos/Moeda');
const ProdutoRepositorio = require('./repositorios/ProdutoRepositorio');
const MoedaRepositorio = require('./repositorios/MoedaRepositorio');
const PrecoService = require('./servicos/PrecoService');
const { ErroNaoEncontrado, ErroValidacao } = require('./erros');

module.exports = function criarRotas(banco) {
  const router = express.Router();
  const produtos = new ProdutoRepositorio(banco.conexao);
  const moedas = new MoedaRepositorio(banco.conexao);
  const precos = new PrecoService(1.0);

  const idDe = (req) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) throw new ErroValidacao('Identificador inválido');
    return id;
  };

  // CRUD genérico reaproveitado por produtos e moedas
  const crud = (caminho, repo, Modelo) => {
    router.get(caminho, (req, res) => res.json(repo.listar()));
    router.post(caminho, (req, res) => res.status(201).json(repo.criar(new Modelo(req.body))));
    router.put(`${caminho}/:id`, (req, res) => {
      const id = idDe(req);
      if (!repo.buscar(id)) throw new ErroNaoEncontrado();
      res.json(repo.atualizar(id, new Modelo({ ...req.body, id })));
    });
    router.delete(`${caminho}/:id`, (req, res) => {
      if (!repo.excluir(idDe(req))) throw new ErroNaoEncontrado();
      res.status(204).end();
    });
  };
  crud('/produtos', produtos, Produto);
  crud('/moedas', moedas, Moeda);

  // Catálogo com preços na moeda do país solicitante: /api/precos?pais=Brasil ou ?moeda=BRL
  router.get('/precos', (req, res) => {
    const { pais, moeda: codigo } = req.query;
    if (!pais && !codigo) throw new ErroValidacao('Informe o país (?pais=Brasil) ou a moeda (?moeda=BRL)');
    const moeda = pais ? moedas.buscarPorPais(pais) : moedas.buscarPorCodigo(codigo);
    if (!moeda) throw new ErroNaoEncontrado('País ou moeda não cadastrado');
    res.json(precos.catalogo(produtos.listar(), moeda));
  });

  return router;
};
