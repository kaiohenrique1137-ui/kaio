const Repositorio = require('./Repositorio');

class ProdutoRepositorio extends Repositorio {
  constructor(db) { super(db, 'produtos'); }

  criar(produto) {
    const info = this.db.prepare(
      `INSERT INTO produtos (nome, descricao, capacidadeMl, custoUsd, estoque)
       VALUES (@nome, @descricao, @capacidadeMl, @custoUsd, @estoque)`).run(produto.paraBanco());
    return this.buscar(info.lastInsertRowid);
  }

  atualizar(id, produto) {
    this.db.prepare(
      `UPDATE produtos SET nome=@nome, descricao=@descricao, capacidadeMl=@capacidadeMl,
       custoUsd=@custoUsd, estoque=@estoque WHERE id=@id`).run({ ...produto.paraBanco(), id });
    return this.buscar(id);
  }
}
module.exports = ProdutoRepositorio;
