// Classe base: operações comuns de acesso ao banco.
class Repositorio {
  constructor(db, tabela) {
    this.db = db;
    this.tabela = tabela;
  }
  listar() { return this.db.prepare(`SELECT * FROM ${this.tabela} ORDER BY id`).all(); }
  buscar(id) { return this.db.prepare(`SELECT * FROM ${this.tabela} WHERE id = ?`).get(id); }
  excluir(id) { return this.db.prepare(`DELETE FROM ${this.tabela} WHERE id = ?`).run(id).changes > 0; }
}
module.exports = Repositorio;
