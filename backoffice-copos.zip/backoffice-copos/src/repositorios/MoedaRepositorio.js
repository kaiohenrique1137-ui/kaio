const Repositorio = require('./Repositorio');

class MoedaRepositorio extends Repositorio {
  constructor(db) { super(db, 'moedas'); }

  criar(moeda) {
    const info = this.db.prepare(
      'INSERT INTO moedas (pais, codigo, taxa) VALUES (@pais, @codigo, @taxa)').run(moeda.paraBanco());
    return this.buscar(info.lastInsertRowid);
  }

  atualizar(id, moeda) {
    this.db.prepare('UPDATE moedas SET pais=@pais, codigo=@codigo, taxa=@taxa WHERE id=@id')
      .run({ ...moeda.paraBanco(), id });
    return this.buscar(id);
  }

  buscarPorPais(pais) {
    return this.db.prepare('SELECT * FROM moedas WHERE pais = ? COLLATE NOCASE').get(pais);
  }

  buscarPorCodigo(codigo) {
    return this.db.prepare('SELECT * FROM moedas WHERE codigo = ? COLLATE NOCASE ORDER BY id').get(codigo);
  }
}
module.exports = MoedaRepositorio;
