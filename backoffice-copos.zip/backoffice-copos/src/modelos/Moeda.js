const { ErroValidacao } = require('../erros');

class Moeda {
  constructor({ id = null, pais, codigo, taxa }) {
    this.id = id;
    this.pais = String(pais ?? '').trim();
    this.codigo = String(codigo ?? '').trim().toUpperCase();
    this.taxa = Number(taxa);
    this.validar();
  }

  validar() {
    const erros = [];
    if (this.pais.length < 2) erros.push('Informe o país');
    if (!/^[A-Z]{3}$/.test(this.codigo)) erros.push('O código da moeda deve ter 3 letras (ex.: BRL)');
    if (!Number.isFinite(this.taxa) || this.taxa <= 0) erros.push('A taxa deve ser maior que zero (unidades da moeda por 1 USD)');
    if (erros.length) throw new ErroValidacao(erros.join('. '));
  }

  paraBanco() {
    const { pais, codigo, taxa } = this;
    return { pais, codigo, taxa };
  }
}
module.exports = Moeda;
