const { ErroValidacao } = require('../erros');

class Produto {
  constructor({ id = null, nome, descricao = '', capacidadeMl, custoUsd, estoque = 0 }) {
    this.id = id;
    this.nome = String(nome ?? '').trim();
    this.descricao = String(descricao ?? '').trim();
    this.capacidadeMl = Number(capacidadeMl);
    this.custoUsd = Number(custoUsd);
    this.estoque = Number(estoque);
    this.validar();
  }

  validar() {
    const erros = [];
    if (this.nome.length < 2) erros.push('Informe o nome do produto (mínimo 2 caracteres)');
    if (!Number.isInteger(this.capacidadeMl) || this.capacidadeMl <= 0) erros.push('A capacidade deve ser um número inteiro maior que zero (ml)');
    if (!Number.isFinite(this.custoUsd) || this.custoUsd < 0) erros.push('O custo em USD deve ser zero ou maior');
    if (!Number.isInteger(this.estoque) || this.estoque < 0) erros.push('O estoque deve ser um inteiro zero ou maior');
    if (erros.length) throw new ErroValidacao(erros.join('. '));
  }

  paraBanco() {
    const { nome, descricao, capacidadeMl, custoUsd, estoque } = this;
    return { nome, descricao, capacidadeMl, custoUsd, estoque };
  }
}
module.exports = Produto;
