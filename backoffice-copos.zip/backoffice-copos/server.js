const express = require('express');
const path = require('path');
const Banco = require('./src/Banco');
const criarRotas = require('./src/rotas');
const { ErroValidacao, ErroNaoEncontrado } = require('./src/erros');

const app = express();
const banco = new Banco();

app.use(express.json());
app.use('/api', criarRotas(banco));
app.use('/api', (req, res) => res.status(404).json({ erro: 'Rota não encontrada' }));
app.use(express.static(path.join(__dirname, 'public')));

app.use((err, req, res, next) => {
  if (err instanceof ErroValidacao) return res.status(400).json({ erro: err.message });
  if (err instanceof ErroNaoEncontrado) return res.status(404).json({ erro: err.message });
  if (String(err.code).startsWith('SQLITE_CONSTRAINT')) {
    return res.status(409).json({ erro: 'Já existe um registro com esses dados' });
  }
  console.error(err);
  res.status(500).json({ erro: 'Erro interno do servidor' });
});

const PORTA = process.env.PORT || 3000;
app.listen(PORTA, () => console.log(`Back-office rodando em http://localhost:${PORTA}`));
